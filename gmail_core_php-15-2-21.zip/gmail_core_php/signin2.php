<?php 
session_start();
 ?>

<!DOCTYPE html>
<html lang="en">

<head>

<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Online Super Bazar,Online Super Bazar Admin Panel, Bootstrap, Admin Panel, Admin Panel, Responsive, Fluid, Retina">
  <title>Email</title>

  <!-- Favicons -->
  <link href="img/logo1.png" rel="icon">
  <link href="img/logo1.png" rel="apple-touch-icon">

   <link rel="stylesheet" href="assets/css/app.min.css">
  <link rel="stylesheet" href="assets/bundles/jquery-selectric/selectric.css">
  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/components.css">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="assets/css/custom.css">
  <!-- show password -->
<script>
$(document).ready(function(){
  $("#show").click(function(){
    $("#psw").attr("type", "text");
    $("#show").hide();
    $("#hide").show();
  });
  $("#hide").click(function(){
    $("#psw").attr("type", "password");
    $("#hide").hide();
    $("#show").show();
  });

// Confirm
  $("#show1").click(function(){
    $("#psw1").attr("type", "text");
    $("#show1").hide();
    $("#hide1").show();
  });
  $("#hide1").click(function(){
    $("#psw1").attr("type", "password");
    $("#hide1").hide();
    $("#show1").show();
  });


});



</script>
<!-- close show password -->


 <style>

.status-available{color:#2FC332; font-size: 12px;}
.status-not-available{color:#D60202;font-size: 12px;}
</style>
  <script type="text/javascript">
    function checkAvailability() {
      jQuery.ajax({
      url: "save/checkusername.php",
      data:'username='+$("#email").val(),
      type: "POST",
      success:function(data){
      // $("#user-availability-status").html(data);
      if(data==0)
      {
        $('#save').prop("disabled", true);
      }
      else
      {
        $('#save').prop("disabled", false);
      }

      },
      error:function (){}
      });
}
  </script>


  <style>

.status-available{color:#2FC332; font-size: 12px;}
.status-not-available{color:#D60202;font-size: 12px;}
</style>
  <script type="text/javascript">
    function checkAvailability() {
      jQuery.ajax({
      url: "save/checkusername.php",
      data:'username='+$("#email").val(),
      type: "POST",
      success:function(data){
      // $("#user-availability-status").html(data);
      if(data==0)
      {
        $('#save').prop("disabled", false);
      }
      else
      {
        $('#save').prop("disabled", true);
      }

      },
      error:function (){}
      });
}
  </script>

</head>

<body>
  <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
 

 <!-- <div class="loader"></div> -->
  <div style="background-image: url('img/bg.png');background-size: 100% 100%;height: 100vh;padding: 0;overflow: hidden;">
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xl-8 offset-xl-2">
            <div class="card card-primary">
              <div class="card-header">
                <h4>Register</h4>
              </div>
              <p style="color: red !important;text-align: center;"><?php include("error.php"); ?></p>
              <div class="card-body">
                <form method="post" action="save/signin2.php" enctype="multipart/form-data">
                  <input type="hidden" name="email" value="<?php echo $_SESSION["email"] ?>">
                  <div class="row">
                  <div class="form-group col-12">
                    <label for="email">Recovery Email</label>
                    <div class="row">
                      <div class="col-md-8">
                        <input id="email" onblur="checkAvailability();" type="text" class="form-control" name="remail" autofocus="" required="">
                        <p id="user-availability-status"></p>
                      </div>
                      <div class="col-md-4">
                        <input id="email" type="email" class="form-control" name="email" value="@smail.com" disabled="">
                      </div>
                    </div>
                    <div class="invalid-feedback">
                     
                    </div>
                  </div>
                  </div>
                  <div class="row">
                    <div class="form-group col-2">
                      <label for="password" class="d-block">Month</label>
                      <select class="form-control" name="month">
                        <option value="january">
                          January
                        </option>
                        <option value="february">
                          February
                        </option>
                        <option value="march">
                          March
                        </option>
                        <option value="april">
                          April
                        </option>
                        <option value="may">
                          May
                        </option>
                        <option value="june">
                          June
                        </option>
                        <option value="july">
                          July
                        </option>
                        <option value="august">
                          August
                        </option>
                        <option value="september">
                          September
                        </option>
                        <option value="ocotber">
                          Ocotber
                        </option>
                        <option value="november">
                          November
                        </option>
                        <option value="december">
                          December
                        </option>
                      </select>
                      <div id="pwindicator" class="pwindicator">
                        <div class="bar"></div>
                        <div class="label"></div>
                      </div>
                    </div>
                    <div class="form-group col-2">
                      <label for="password" class="d-block">Date</label>
                      <input id="psw" type="number" class="form-control" data-indicator="pwindicator" name="date" required="">
                      <div id="pwindicator" class="pwindicator">
                        <div class="bar"></div>
                        <div class="label"></div>
                      </div>
                    </div>
                    <div class="form-group col-2">
                      <label for="password" class="d-block">Year</label>
                      <input id="psw" type="number" class="form-control" data-indicator="pwindicator" name="year" required="">
                      <div id="pwindicator" class="pwindicator">
                        <div class="bar"></div>
                        <div class="label"></div>
                      </div>
                    </div>
                    <div class="form-group col-6">
                      <label for="password2" class="d-block">Gender</label>
                      <select class="form-control" name="gender">
                        <option>
                          --Select--
                        </option>
                        <option value="male">
                          Male
                        </option value="female">
                        <option>
                          Female
                        </option>
                        <option value="other">
                          Other
                        </option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" name="agree" class="custom-control-input" id="agree">
                      <label class="custom-control-label" for="agree">I agree with the terms and conditions</label>
                    </div>
                  </div>
                    <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block" id="save" name="save_register">
                      Register
                    </button>
                  </div>
                </form>
              </div>
              <div class="mb-4 text-muted text-center">
                Already Registered? <a href="login.php">Login</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>

  <!-- General JS Scripts -->
  <script src="assets/js/app.min.js"></script>
  <!-- JS Libraies -->
  <script src="assets/bundles/jquery-pwstrength/jquery.pwstrength.min.js"></script>
  <script src="assets/bundles/jquery-selectric/jquery.selectric.min.js"></script>
  <!-- Page Specific JS File -->
  <script src="assets/js/page/auth-register.js"></script>
  <!-- Template JS File -->
  <script src="assets/js/scripts.js"></script>
  <!-- Custom JS File -->
  <script src="assets/js/custom.js"></script>
  <script>
    $.backstretch("img/bg.png", {
      speed: 500
    });
  </script>
</body>

</html>
