<?php 
include("check_session.php");
include('header/header.php'); 
include("error.php");
?>


<!-- Main Content -->
<div class="main-content">
<section class="section">
<div class="section-body">
<div class="row">
<p style="color: red !important;"><?php include("error.php"); ?></p>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
      <div class="card">
        <div class="boxs mail_listing">
          <div class="inbox-body no-pad">
<?php 
include('connection.php');
$id=$_GET["id"];
$sql = "SELECT * FROM `user_mail` WHERE `id`='$id' ";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>
            <section class="mail-list">
              <div class="mail-sender">
                <div class="mail-heading">
                  <h4 class="vew-mail-header">
                    <b>Hi <?php echo $_SESSION['username']; ?>, How are you?</b>
                  </h4>
                </div>
                <hr>
                <div class="media" style="display: <?php if($row["extra_mail"]!=''){ ?>none;<?php } ?>">
                  <a href="#" class="table-img m-r-15">
                    <?php 
                    $sql = "SELECT `img` FROM `user` WHERE `email`='".$row["reply_to"]."' OR `email`='".$row['mail_to']."' ";
                    $result = $conn->query($sql);
                    $row_pic = $result->fetch_assoc();
                     ?>
                      <img alt="image" src="upload/profile_pic/<?php echo $row_pic['img']; ?>" class="rounded-circle" width="35" data-toggle="tooltip" title="Sachin Pandit" style="display: <?php if($row["mail_from"]=='smail'){ ?>none;<?php } ?>">
                  </a>
                  <div class="media-body">
                    <span class="date pull-right"><?php echo $row['time']; ?><br> <?php echo $row['date']; ?></span>
                    <!-- <h5 class="text-primary">Sarah Smith</h5> -->
                    <small class="text-muted"><span style="font-size: 20px;"><?php if($row["reply_to"]=='') { echo "To"; } else{echo "Reply To";} ?>:</span> 
                  <h1>
                   <?php
                    $mail_id=$row["mail_to"].'@smail.com';
                    if($row["mail_from"]=='smail')
                      { 
                        echo$row["mail_from"];
                      }
                  elseif ($row["reply_to"]!='')
                      {
                        echo $row["reply_to"].'@smail.com';
                      } 
                     else
                      { 
                        echo $mail_id; 
                      }
                    ?>
                  </h1></small>
                  </div>
                </div>
                <!-- address not found -->
                <div class="media" style="display: <?php if($row["extra_mail"]==''){ ?>none;<?php } ?>">
                  <p><?php echo $row['subject']; ?></p>
                  <div class="card-body mt-5 box" style="width: 300px;border: 1px solid white;">
                    <h1>Address Not Found</h1>
                    <h4>Your message wasn't delivered to</h4>
                    <h5 style="font-weight: 800;color: black;"><?php echo $row['extra_mail']; ?> <h6 style="font-size: 20px;">because the address couldn't be found, or is unable to receive mail.</h6></h5>
                  </div>
                </div>
                <!-- address not found -->
              </div>

              <!-- subject -->
              <div class="view-mail p-t-20" style="display: <?php if($row["extra_mail"]!=''){ ?>none;<?php } ?>">
                <h4>
                 <?php if($row["reply_to"]=='')
                 {
                  echo $row['subject'];
                 }
                 else
                 {
                  echo $row['reply_msg'];
                 }
                  ?></h4>
              </div>
              <!-- close subject -->

              <div class="attachment-mail" style="display: <?php if($row["extra_mail"]!=''){ ?>none;<?php } ?>">
                <div class="row">
                    <!-- attachment -->
                  <div class="col-md-2" style="display: <?php if($row["mail_from"]=='smail'){ ?>none;<?php } ?>">
                    <a href="save/download.php?file=upload/<?php echo $row['img'] ?>" download="upload/<?php echo $row['img']; ?>" style="display: <?php if($row["reply_from"]!=''){ ?>none;<?php } ?>">
                      <img class="img-thumbnail img-responsive" alt="attachment"
                        src="upload/<?php echo $row['img']; ?>" style="display: <?php if($row["reply_from"]!=''){ ?>none;<?php } ?>">
                    </a>
                     <a href="save/download.php?file=upload/<?php echo $row['img'] ?>" download="upload/<?php echo $row['img']; ?>" style="display: <?php if($row["reply_from"]!=''){ ?>none;<?php } ?>"><?php echo $row['img']; ?>
                     </a>

                     <!-- open reply -->
                    <a href="save/download1.php?file=upload/reply/<?php echo $row['img'] ?>" download="upload/reply/<?php echo $row['img']; ?>" style="display: <?php if($row["reply_from"]==''){ ?>none;<?php } ?>">
                      <img class="img-thumbnail img-responsive" alt="attachment"
                        src="upload/reply/<?php echo $row['img']; ?>" style="display: <?php if($row["reply_from"]==''){ ?>none;<?php } ?>">
                    </a>
                    <a href="save/download1.php?file=upload/reply/<?php echo $row['img'] ?>" download="upload/<?php echo $row['img']; ?>" style="display: <?php if($row["reply_from"]==''){ ?>none;<?php } ?>"><?php echo $row['img']; ?>
                    </a>
                    <!-- close reply -->
                  </div>
                   <!-- close attachment -->

                   <!-- open verification code -->
                   <div class="col-md-12 ml-4" style="display: <?php if($row["mail_from"]!='smail'){ ?>none;<?php } ?>">
                     <p style="font-size: 22px;color: black;">smail received a request to use this email address to help recover smail Account <br>
                  <?php 
                  $sql_mail="SELECT * FROM `user` WHERE `recovery_mail`='".$row["mail_to"]."' ";
                  $result_mail=$conn->query($sql_mail);
                  $total=$result_mail->num_rows;
                  $row_mail=$result_mail->fetch_assoc();
                  $mail=$row_mail["email"].'@smail.com'
                   ?>
                      <a href="compose_mail.php?mail=<?php echo $mail ?>" style="font-size: 20px;"><?php echo $mail; ?></a></p>
                      <div class="row">
                        <div class="col-md-4">
                          
                        </div>
                        <div class="col-md-4">
                          <h1 style="color: black;"><?php echo $row["otp"]; ?></h1>
                        </div>
                        <div class="col-md-4">
                          
                        </div>
                      </div>
                      <p style="font-size: 22px;color: black;">Enter the code when asked for it to show that smail can reach you at this email address.</p>
                      <p style="font-size: 22px;color: black;">If you don’t recognize <a href="compose_mail.php?mail=<?php echo $mail ?>" style="font-size: 20px;"><?php echo $mail; ?></a>, someone probably gave your email address by mistake. You can safely ignore this email.</p>
                      <p style="color: black;font-size: 22px;">Sincerely,<br>
                      The Smail Accounts Team</p>
                   </div>
                   <!-- close verification code -->

                   <!-- open reply msg form server -->
                   <div class="col-md-12 ml-4 mt-3" style="display: <?php if($row["extra_mail"]!=''){ ?>none;<?php } ?>"> 
                     <?php
              $sql_name1="SELECT * FROM `user` WHERE `email`='".$row["reply_to"]."'  ";
              $result_name1=$conn->query($sql_name1);
              $total_name1=$result_name1->num_rows;
              $row_name1=$result_name1->fetch_assoc();
                ?>
                   <h4 style="display: <?php if($row["reply_from"]==''){ ?>none;<?php } ?>">
                     On <?php echo $row["send_date"]; ?> at  <?php echo $row["send_time"]; ?> <?php echo ucwords($row_name1['username']).' ', ucwords($row_name1['lname']); ?> <
                     <a href="compose_mail.php?mail=<?php echo $row["reply_to"].'@smail.com'; ?>">
                     <?php echo $row["reply_to"].'@smail.com'; ?>
                     </a>
                     > wrote:<br> <?php echo $row["send_msg"]; ?>
                   </h4>
                   </div>
                   <!-- close reply msg from server -->
                </div>
              </div>
              <div class="replyBox m-t-20">
                <p class="p-b-20" style="font-size: 20px;">click here to
                  <a style="cursor: pointer;color: white;" class="btn btn-primary" id="reply_btn">Reply</a> or
                  <a href="#" class="btn btn-primary">Forward</a>
                </p>

                  <!-- reply -->
                  <form method="post" action="save/reply.php" enctype="multipart/form-data" style="display: none;" id="reply_form">
                    <div class="view-mail">
                     <input type="hidden" name="reply_from" value="<?php echo $_SESSION["email"]; ?>">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <input type="hidden" name="time" value="<?php echo $row["time"]; ?>">
                    <input type="hidden" name="date" value="<?php echo $row["date"]; ?>">
                   <input type="hidden" name="send_msg" value="<?php echo $row["subject"]; ?>">
              <?php
              $sql_name="SELECT * FROM `user` WHERE `email`='".$row["mail_to"]."' OR `email`='".$row["reply_to"]."'  ";
              $result_name=$conn->query($sql_name);
              $total_name=$result_name->num_rows;
              $row_name=$result_name->fetch_assoc();
                ?>
                <h4>
                  <div class="container">
                    <div class="row">
                      <div class="col-md-1">
                        <img alt="image" src="upload/profile_pic/<?php echo $_SESSION['user_img']; ?>" class="user-img-radious-style" style="height: 50px;">
                      </div>
                <div class="col-md-10 card">
                 <div class="row">
                    <div class="col-md-1">
                    <i class="fa fa-reply" aria-hidden="true"></i>
                  </div>
                  <div class="col-md-11">
                    <div class="row">
                       <div class="col-md-2">
                       <input type="text" value="<?php echo ucwords($row_name['username']).' ', ucwords($row_name['lname']); ?>" style="border: none;font-size: 20px;">
                     </div>
                     <div class="col-md-10">
                      <?php echo "<"; ?>
                      <input type="text" name="reply_to" value="<?php echo $row_name['email'].'@smail.com'; ?>" style="border: none;font-size: 20px;">                     
                       <?php echo ">"; ?>
                     </div> 
                    </div> 
                  </div>
                 </div>
                 
                  <br>
                  <textarea rows="7" cols="70" style="border: 1px solid lightgrey;" name="reply_msg">
                    
                  </textarea>
                  <input type="file" name="file" class="form-control"><br>
                  <button class="btn btn-primary" style="width: 100px;height: 50px;font-size: 20px;" name="save_reply">Send</button>
                  <br>
                </div>
                    </div>
                  </div>
                </h4>
              </div>
              </form>
                  <!-- close reply -->
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
</div>
</div>
</section>
<div class="settingSidebar">
<a href="javascript:void(0)" class="settingPanelToggle"> <i class="fa fa-spin fa-cog"></i>
</a>
<div class="settingSidebar-body ps-container ps-theme-default">
<div class=" fade show active">
<div class="setting-panel-header">Setting Panel
</div>
<div class="p-15 border-bottom">
  <h6 class="font-medium m-b-10">Select Layout</h6>
  <div class="selectgroup layout-color w-50">
    <label class="selectgroup-item">
      <input type="radio" name="value" value="1" class="selectgroup-input-radio select-layout" checked>
      <span class="selectgroup-button">Light</span>
    </label>
    <label class="selectgroup-item">
      <input type="radio" name="value" value="2" class="selectgroup-input-radio select-layout">
      <span class="selectgroup-button">Dark</span>
    </label>
  </div>
</div>
<div class="p-15 border-bottom">
  <h6 class="font-medium m-b-10">Sidebar Color</h6>
  <div class="selectgroup selectgroup-pills sidebar-color">
    <label class="selectgroup-item">
      <input type="radio" name="icon-input" value="1" class="selectgroup-input select-sidebar">
      <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip"
        data-original-title="Light Sidebar"><i class="fas fa-sun"></i></span>
    </label>
    <label class="selectgroup-item">
      <input type="radio" name="icon-input" value="2" class="selectgroup-input select-sidebar" checked>
      <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip"
        data-original-title="Dark Sidebar"><i class="fas fa-moon"></i></span>
    </label>
  </div>
</div>
<div class="p-15 border-bottom">
  <h6 class="font-medium m-b-10">Color Theme</h6>
  <div class="theme-setting-options">
    <ul class="choose-theme list-unstyled mb-0">
      <li title="white" class="active">
        <div class="white"></div>
      </li>
      <li title="cyan">
        <div class="cyan"></div>
      </li>
      <li title="black">
        <div class="black"></div>
      </li>
      <li title="purple">
        <div class="purple"></div>
      </li>
      <li title="orange">
        <div class="orange"></div>
      </li>
      <li title="green">
        <div class="green"></div>
      </li>
      <li title="red">
        <div class="red"></div>
      </li>
    </ul>
  </div>
</div>
<div class="p-15 border-bottom">
  <div class="theme-setting-options">
    <label class="m-b-0">
      <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input"
        id="mini_sidebar_setting">
      <span class="custom-switch-indicator"></span>
      <span class="control-label p-l-10">Mini Sidebar</span>
    </label>
  </div>
</div>
<div class="p-15 border-bottom">
  <div class="theme-setting-options">
    <label class="m-b-0">
      <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input"
        id="sticky_header_setting">
      <span class="custom-switch-indicator"></span>
      <span class="control-label p-l-10">Sticky Header</span>
    </label>
  </div>
</div>
<div class="mt-4 mb-4 p-3 align-center rt-sidebar-last-ele">
  <a href="#" class="btn btn-icon icon-left btn-primary btn-restore-theme">
    <i class="fas fa-undo"></i> Restore Default
  </a>
</div>
</div>
</div>
</div>
</div>
<?php include('footer/index.php'); ?>
</div>
</div>
<!-- General JS Scripts -->
<script src="assets/js/app.min.js"></script>
<!-- JS Libraies -->
<!-- Page Specific JS File -->
<!-- Template JS File -->
<script src="assets/js/scripts.js"></script>
<!-- Custom JS File -->
<script src="assets/js/custom.js"></script>

<script>
$(document).ready(function(){
$("#reply_btn").click(function(){
$("#reply_form").slideToggle("slow");
});
});
</script>

</body>


<!-- email-inbox.html  21 Nov 2019 03:50:58 GMT -->
</html>