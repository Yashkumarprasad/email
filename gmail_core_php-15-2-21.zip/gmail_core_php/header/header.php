<!DOCTYPE html>
<html lang="en">


<!-- email-inbox.html  21 Nov 2019 03:50:57 GMT -->
<head>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title><?php
   $space=" ";
   echo ucwords($_SESSION['username']) ,$space , ucwords($_SESSION['lname']); ?></title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="assets/css/app.min.css">
  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/components.css">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="assets/css/custom.css">
  <link rel='shortcut icon' type='image/x-icon' href='upload/profile_pic/<?php echo $_SESSION['user_img']; ?>' />
</head>
<body>
<!-- <div class="loader"></div> -->
<div id="app">
<div class="main-wrapper main-wrapper-1">
  <div class="navbar-bg"></div>
  <nav class="navbar navbar-expand-lg main-navbar sticky">
    <div class="form-inline mr-auto">
      <ul class="navbar-nav mr-3">
        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg
              collapse-btn"> <i data-feather="align-justify"></i></a></li>
        <li><a href="#" class="nav-link nav-link-lg fullscreen-btn">
            <i data-feather="maximize"></i>
          </a></li>
        <li>
          <form class="form-inline mr-auto">
            <div class="search-element">
              <input class="form-control" type="search" placeholder="Search" aria-label="Search" data-width="200">
              <button class="btn" type="submit">
                <i class="fas fa-search"></i>
              </button>
            </div>
          </form>
        </li>
      </ul>
    </div>
    <ul class="navbar-nav navbar-right">
      <li class="dropdown"><a href="#" data-toggle="dropdown"
          class="nav-link dropdown-toggle nav-link-lg nav-link-user"> <img alt="image" src="upload/profile_pic/<?php echo $_SESSION['user_img']; ?>" class="user-img-radious-style"> <span class="d-sm-none d-lg-inline-block"></span></a>
        <div class="dropdown-menu dropdown-menu-right pullDown">
          <div class="dropdown-title">Hello <?php 
          $space=" ";
          echo $_SESSION['username'] ,$space, $_SESSION['lname']; ?></div>
          <a href="profile.html" class="dropdown-item has-icon"> <i class="far
                fa-user"></i> Profile
          </a> <a href="timeline.html" class="dropdown-item has-icon"> <i class="fas fa-bolt"></i>
            Activities
          </a> <a href="#" class="dropdown-item has-icon"> <i class="fas fa-cog"></i>
            Settings
          </a>
          <div class="dropdown-divider"></div>
          <a href="logout.php" class="dropdown-item has-icon text-danger"> <i class="fas fa-sign-out-alt"></i>
            Logout
          </a>
        </div>
      </li>
    </ul>
  </nav>
  <div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
      <div class="sidebar-brand">
        <a href="index.html"> <img alt="image" src="upload/profile_pic/<?php echo $_SESSION['user_img']; ?>" class="header-logo" /> <span
            class="logo-name" title="<?php echo ucwords($_SESSION['username']); ?>"><?php echo substr($_SESSION['username'], 0,9); ?></span>
        </a>
      </div>
      <div id="mail-nav">
                  <a type="button" href="compose.php" class="btn btn-danger waves-effect btn-compose" style="color: white;">COMPOSE</a>
                  <ul class="" id="mail-folders">
                    <?php
include('connection.php');
$email = $_SESSION['email'];
$sql_unread = "SELECT * FROM `user_mail` WHERE `status`=1 AND (`mail_to`='$email' OR `reply_to`='$email') ";
$result_unread = $conn->query($sql_unread);
$total_unread = $result_unread->num_rows;
  ?> 
                    <li>
                      <a href="index.php" title="Inbox">Inbox <span style="float: right;">(<?php echo $total_unread; ?>)</span>
                      </a>
                    </li>
                    <li>
                      <a href="sent.php" title="Sent">Sent</a>
                    </li>
                    <li>
                      <a href="javascript:;" title="Draft">Draft</a>
                    </li>
                    <li>
                      <a href="javascript:;" title="Bin">Bin</a>
                    </li>
                    <li>
                      <a href="javascript:;" title="Important">Important</a>
                    </li>
                    <li>
                      <a href="star.php" title="Starred">Starred</a>
                    </li>
                  </ul>
                 <!--  <h5 class="b-b p-10 text-strong">Labels</h5>
                  <ul class="" id="mail-labels">
                    <li>
                      <a href="javascript:;">
                        <i class="material-icons col-red">local_offer</i>Family</a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="material-icons col-blue">local_offer</i>Work</a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="material-icons col-orange">local_offer</i>Shop</a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="material-icons col-cyan">local_offer</i>Themeforest</a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="material-icons col-blue-grey">local_offer</i>Google</a>
                    </li>
                  </ul>
                  <h5 class="b-b p-10 text-strong">Online</h5>
                  <ul class="online-user" id="online-offline">
                    <li><a href="javascript:;"> <img alt="image" src="assets/img/users/user-2.png"
                          class="rounded-circle" width="35" data-toggle="tooltip" title="Sachin Pandit">
                        Sachin Pandit
                      </a></li>
                    <li><a href="javascript:;"> <img alt="image" src="assets/img/users/user-1.png"
                          class="rounded-circle" width="35" data-toggle="tooltip" title="Sarah Smith">
                        Sarah Smith
                      </a></li>
                    <li><a href="javascript:;"> <img alt="image" src="assets/img/users/user-3.png"
                          class="rounded-circle" width="35" data-toggle="tooltip" title="Airi Satou">
                        Airi Satou
                      </a></li>
                    <li><a href="javascript:;"> <img alt="image" src="assets/img/users/user-4.png"
                          class="rounded-circle" width="35" data-toggle="tooltip" title="Angelica Ramos ">
                        Angelica Ramos
                      </a></li>
                    <li><a href="javascript:;"> <img alt="image" src="assets/img/users/user-5.png"
                          class="rounded-circle" width="35" data-toggle="tooltip" title="Cara Stevens">
                        Cara Stevens
                      </a></li>
                  </ul> -->
                </div>
    </aside>
  </div>