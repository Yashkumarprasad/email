<?php 
include("check_session.php");
include('header/header.php'); 
include("error.php");
?>


<!-- Main Content -->
<div class="main-content">
<section class="section">
<div class="section-body">
<div class="row">
<p style="color: red !important;"><?php include("error.php"); ?></p>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="card">
<div class="boxs mail_listing">
  <div class="inbox-center table-responsive">
    <table class="table table-hover">
      <thead>
        <tr>
          <th colspan="3">
            <div class="inbox-header">
              <div class="mail-option">
                <div class="email-btn-group m-l-15">
                  <a href="#" class="col-dark-gray waves-effect m-r-20" title="back"
                    data-toggle="tooltip">
                    <i class="material-icons">keyboard_return</i>
                  </a>
                  <a href="#" class="col-dark-gray waves-effect m-r-20" title="Archive"
                    data-toggle="tooltip">
                    <i class="material-icons">archive</i>
                  </a>
                  <div class="p-r-20">|</div>
                  <a href="#" class="col-dark-gray waves-effect m-r-20" title="Error"
                    data-toggle="tooltip">
                    <i class="material-icons">error</i>
                  </a>
                  <a href="#" class="col-dark-gray waves-effect m-r-20" title="Delete"
                    data-toggle="tooltip">
                    <i class="material-icons">delete</i>
                  </a>
                  <a href="#" class="col-dark-gray waves-effect m-r-20" title="Folders"
                    data-toggle="tooltip">
                    <i class="material-icons">folder</i>
                  </a>
                  <a href="#" class="col-dark-gray waves-effect m-r-20" title="Tag"
                    data-toggle="tooltip">
                    <i class="material-icons">local_offer</i>
                  </a>
                </div>
              </div>
            </div>
          </th>
          <th class="hidden-xs" colspan="2">
            <div class="pull-right">
              <div class="email-btn-group m-l-15">
                <a href="#" class="col-dark-gray waves-effect m-r-20" title="previous"
                  data-toggle="tooltip">
                  <i class="material-icons">navigate_before</i>
                </a>
                <a href="#" class="col-dark-gray waves-effect m-r-20" title="next"
                  data-toggle="tooltip">
                  <i class="material-icons">navigate_next</i>
                </a>
              </div>
            </div>
          </th>
        </tr>
      </thead>
      <tbody>
<?php
include('connection.php');
$email = $_SESSION['email'];
$sql = "SELECT * FROM `user_mail` WHERE `mail_to`='$email' OR `reply_to`='$email' ORDER BY `id` DESC ";
$result = $conn->query($sql);
$total = $result->num_rows;
if($total>0){
while($row = $result->fetch_assoc())
{
?> 
          <tr>
          </td>
          <td class="hidden-xs">
            <a href="save/star.php?id=<?php echo $row['id']; ?> & star_status=<?php echo $row["star_status"]; ?>">
              <i class="material-icons" style="font-weight: <?php if($row["status"]==1){ ?>bold <?php }elseif ($row["status"]==0){?>normal<?php } ?>;color: blue;">
                <?php if($row["star_status"]==0){ ?>star_border<?php }elseif($row["star_status"]==1){ ?><span style="color: blue;">star</span><?php } ?>
                </i>
            </a>
          </td>
          <td class="max-texts">
            <a href="read.php?id=<?php echo $row["id"];?>" style="font-weight: <?php if($row["status"]==1){ ?>bold <?php }elseif ($row["status"]==0){?>normal<?php } ?>;">
           From: 
        <?php
          if($row["mail_from"]!='smail')
           { 
            if($row["mail_from"]==$_SESSION["email"]){
                echo "Me";
              } 
              elseif ($row["reply_from"]!='')
              {
                if($row["reply_from"]==$_SESSION['email'])
                  {
                    echo "Me";
                  }
               else
                 {
                   echo $row["reply_from"].'@smail.com';
                 }
              } 
            else
              {
                echo $row['mail_from'].'@smail.com';
              }
            }
          else
           {
              echo $row["mail_from"]; 
           }
          ?>
          </a>
        </td>
          <td class="max-texts">
            <a href="read.php?id=<?php echo $row["id"];?>" style="font-weight: <?php if($row["status"]==1){ ?>bold <?php }elseif ($row["status"]==0){?>normal<?php } ?>;">
             <!--  <span class="badge badge-primary">Work</span> -->
          <?php 
          if($row["subject"]=='')
            {
              echo "(no subject)";
            }
          if($row["extra_mail"]=='')
            {
              if($row["reply_from"]=='')
              {
                echo substr($row['subject'],0,30);
              }
              else
              {
                echo substr($row['reply_msg'], 0,30);
              }
            }
            else
              {
                echo "Address not found";
              } 
            ?>
              </a>
          </td>
          <td class="hidden-xs">
            <a href="save/delete_mail.php?id=<?php echo $row['id'] ?>;"><i class="material-icons" style="font-weight: <?php if($row["status"]==1){ ?>bold <?php }elseif ($row["status"]==0){?>normal<?php } ?>;color: black;">delete</i></a>
          </td>
          <td class="text-right" style="font-weight: <?php if($row["status"]==1){ ?>bold <?php }elseif ($row["status"]==0){?>normal<?php } ?>;"> <?php echo $row['time']; ?> </td>
        </tr>
<?php }}else{echo "0 Result Found";} ?>
        </tr>
      </tbody>
    </table>
  </div>
  <div class="row">
    <div class="col-sm-7 ">
      <p class="p-15">Showing 1 - 15 of 200</p>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</section>
<div class="settingSidebar">
<a href="javascript:void(0)" class="settingPanelToggle"> <i class="fa fa-spin fa-cog"></i>
</a>
<div class="settingSidebar-body ps-container ps-theme-default">
<div class=" fade show active">
<div class="setting-panel-header">Setting Panel
</div>
<div class="p-15 border-bottom">
<h6 class="font-medium m-b-10">Select Layout</h6>
<div class="selectgroup layout-color w-50">
<label class="selectgroup-item">
  <input type="radio" name="value" value="1" class="selectgroup-input-radio select-layout" checked>
  <span class="selectgroup-button">Light</span>
</label>
<label class="selectgroup-item">
  <input type="radio" name="value" value="2" class="selectgroup-input-radio select-layout">
  <span class="selectgroup-button">Dark</span>
</label>
</div>
</div>
<div class="p-15 border-bottom">
<h6 class="font-medium m-b-10">Sidebar Color</h6>
<div class="selectgroup selectgroup-pills sidebar-color">
<label class="selectgroup-item">
  <input type="radio" name="icon-input" value="1" class="selectgroup-input select-sidebar">
  <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip"
    data-original-title="Light Sidebar"><i class="fas fa-sun"></i></span>
</label>
<label class="selectgroup-item">
  <input type="radio" name="icon-input" value="2" class="selectgroup-input select-sidebar" checked>
  <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip"
    data-original-title="Dark Sidebar"><i class="fas fa-moon"></i></span>
</label>
</div>
</div>
<div class="p-15 border-bottom">
<h6 class="font-medium m-b-10">Color Theme</h6>
<div class="theme-setting-options">
<ul class="choose-theme list-unstyled mb-0">
  <li title="white" class="active">
    <div class="white"></div>
  </li>
  <li title="cyan">
    <div class="cyan"></div>
  </li>
  <li title="black">
    <div class="black"></div>
  </li>
  <li title="purple">
    <div class="purple"></div>
  </li>
  <li title="orange">
    <div class="orange"></div>
  </li>
  <li title="green">
    <div class="green"></div>
  </li>
  <li title="red">
    <div class="red"></div>
  </li>
</ul>
</div>
</div>
<div class="p-15 border-bottom">
<div class="theme-setting-options">
<label class="m-b-0">
  <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input"
    id="mini_sidebar_setting">
  <span class="custom-switch-indicator"></span>
  <span class="control-label p-l-10">Mini Sidebar</span>
</label>
</div>
</div>
<div class="p-15 border-bottom">
<div class="theme-setting-options">
<label class="m-b-0">
  <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input"
    id="sticky_header_setting">
  <span class="custom-switch-indicator"></span>
  <span class="control-label p-l-10">Sticky Header</span>
</label>
</div>
</div>
<div class="mt-4 mb-4 p-3 align-center rt-sidebar-last-ele">
<a href="#" class="btn btn-icon icon-left btn-primary btn-restore-theme">
<i class="fas fa-undo"></i> Restore Default
</a>
</div>
</div>
</div>
</div>
</div>
<?php include('footer/index.php'); ?>
</div>
</div>
<!-- General JS Scripts -->
<script src="assets/js/app.min.js"></script>
<!-- JS Libraies -->
<!-- Page Specific JS File -->
<!-- Template JS File -->
<script src="assets/js/scripts.js"></script>
<!-- Custom JS File -->
<script src="assets/js/custom.js"></script>
</body>


<!-- email-inbox.html  21 Nov 2019 03:50:58 GMT -->
</html>