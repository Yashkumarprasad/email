-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2021 at 08:29 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mail`
--
CREATE DATABASE IF NOT EXISTS `mail` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `mail`;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(250) UNSIGNED NOT NULL AUTO_INCREMENT,
  `img` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lname` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recovery_mail` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `month` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otp` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `img`, `username`, `lname`, `email`, `password`, `recovery_mail`, `month`, `date`, `year`, `gender`, `otp`) VALUES
(10, 'comment_2.jpg', 'yash', 'prasad', 'yashkumarprasad14', '1234', 'abkumar794', 'march', '14', '2001', 'male', '5377'),
(11, 'a4.jpg', 'Abhishek', 'Jha', 'abkumar794', '1234', 'yashkumarprasad14', 'ocotber', '10', '2000', 'male', '228'),
(12, 'ab1.jpg', 'Pooja', 'Garg', 'poojagarg', '1234', 'yashkumarprasad14', 'july', '21', '2000', 'Female', '4816'),
(13, 'fr-06.jpg', 'manish', 'soni', 'manishsoni94601', '#Manish@1234', 'yashkumarprasad14', 'july', '14', '2001', 'male', NULL),
(15, 'fr-03.jpg', 'rahul', 'jain', 'rahuljain', '#Rahul@1234', 'yashkumarprasad14', 'september', '3', '2000', 'male', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_mail`
--

DROP TABLE IF EXISTS `user_mail`;
CREATE TABLE IF NOT EXISTS `user_mail` (
  `id` int(250) UNSIGNED NOT NULL AUTO_INCREMENT,
  `mail_from` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reply_from` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mail_to` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `forget_mail` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reply_to` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reply_msg` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `time` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `send_date` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `send_time` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `send_msg` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `extra_mail` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(250) DEFAULT NULL,
  `star_status` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otp` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_mail`
--

INSERT INTO `user_mail` (`id`, `mail_from`, `reply_from`, `mail_to`, `forget_mail`, `reply_to`, `subject`, `reply_msg`, `img`, `date`, `time`, `send_date`, `send_time`, `send_msg`, `extra_mail`, `status`, `star_status`, `otp`) VALUES
(125, 'yashkumarprasad14', NULL, 'yashkumarprasad14', NULL, NULL, '', NULL, 'Array', '13-Feb-2021', '03:37:49pm', NULL, NULL, NULL, NULL, 0, '0', NULL),
(126, 'yashkumarprasad14', NULL, 'yashkumarprasad14', NULL, NULL, '', NULL, '', '13-Feb-2021', '03:44:57pm', NULL, NULL, NULL, NULL, 0, '0', NULL),
(128, 'yashkumarprasad14', NULL, 'yashkumarprasad14', NULL, NULL, '', NULL, '1613211693_4.jpg,1613211693_5.jpg', '13-Feb-2021', '03:51:33pm', NULL, NULL, NULL, NULL, 0, '0', NULL),
(129, NULL, 'yashkumarprasad14', NULL, NULL, 'yashkumarprasad14', ' hii       \r\n      ', ' hii       \r\n      ', '1613212507_5.jpg', '13-Feb-2021', '04:05:07pm', '13-Feb-2021', '03:51:33pm', '', NULL, 0, '0', NULL),
(130, NULL, 'yashkumarprasad14', NULL, NULL, 'yashkumarprasad14', ' hlw       \r\n      ', ' hlw       \r\n      ', '1613212658_5.jpg,1613212658_6.jpg', '13-Feb-2021', '04:07:38pm', '13-Feb-2021', '04:05:07pm', ' hii       \r\n      ', NULL, 0, '0', NULL),
(133, 'smail', NULL, 'yashkumarprasad14', 'poojagarg', NULL, 'Smail Verification Code', NULL, NULL, '15-Feb-2021', '11:42:23am', NULL, NULL, NULL, NULL, 0, '0', '4816');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
