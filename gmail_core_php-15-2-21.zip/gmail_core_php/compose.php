<?php 
include("check_session.php");
// session_start();
include('header/header.php'); 
include("error.php");
?>

<!-- Main Content -->
<div class="main-content">
    <section class="section">
      <div class="section-body">
        <div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="card">
              <div class="boxs mail_listing">
                <div class="inbox-center table-responsive">
                  <table class="table table-hover">
                    <thead>
                      <tr>
                        <th colspan="1">
                          <div class="inbox-header">
                            Compose New Message
                          </div>
                        </th>
                      </tr>
                    </thead>
                  </table>
                </div>
                <div class="row">
                  <div class="col-lg-12">
                    <p style="color: red !important;">
                      <?php include("error.php"); ?>
                      </p>
                    <form class="composeForm" method="post" action="save/compose.php" enctype="multipart/form-data">
                       <div class="form-group">
                        <div class="form-line">
                          <label>From</label>
                          <!-- <input type="email" id="email_address" class="form-control" name="mail_from" value="<?php
                           // echo $_SESSION['email']; ?>"disabled> -->
                          <input type="text" class="form-control" name="mail_from" value="<?php echo $_SESSION['email'].'@smail.com'; ?>">
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="form-line">
                          <input type="email" id="email_address" class="form-control" name="to" placeholder="TO" required="">
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="form-line">
                          <input type="text" id="subject" class="form-control" name="subject" placeholder="Subject">
                        </div>
                      </div>
                      <!-- <textarea rows="5" cols="150" id="ckeditor" name="description">
                          </textarea> -->
                      <div class="compose-editor m-t-20">
                        <div id="summernote"></div>
                        <input type="file" name="file[]" class="default" multiple="multiple" directory="">
                      </div>
                      <br>
                  <div class="col-lg-12">
                    <div class="m-l-25 m-b-20">
                      <button type="submit" class="btn btn-info btn-border-radius waves-effect" name="send_mail">Send</button>
                     <!--  <button type="button" class="btn btn-danger btn-border-radius waves-effect">Discard</button> -->
                    </div>
                  </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php include('footer/index.php'); ?>
</div>
</div>
<!-- General JS Scripts -->
<script src="assets/js/app.min.js"></script>
<!-- JS Libraies -->
<!-- Page Specific JS File -->
<!-- Template JS File -->
<script src="assets/js/scripts.js"></script>
<!-- Custom JS File -->
<script src="assets/js/custom.js"></script>
</body>


<!-- email-inbox.html  21 Nov 2019 03:50:58 GMT -->
</html>