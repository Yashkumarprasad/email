<?php 
include('../connection.php');
session_start();
if(isset($_POST["save_register"]))
{
	$remail=str_replace('@smail.com', "", $_POST["remail"]);
	$month=$_POST["month"];
	$date=$_POST["date"];
	$year=$_POST["year"];
	$gender=$_POST["gender"];
	$email=$_POST["email"];
	$sql="UPDATE `user` SET `recovery_mail`='$remail', `month`='$month', `date`='$date', `year`='$year', `gender`='$gender' WHERE `email`='$email' ";
	if($conn->query($sql)==true)
	{
		$_SESSION["error"]="You are now register";
		header("Location: ../login.php");
	}
	else 
	{
		$_SESSION["error"]="Something Went Wrong";
		header("Location: ../signin2.php");
	}
}

 ?>
