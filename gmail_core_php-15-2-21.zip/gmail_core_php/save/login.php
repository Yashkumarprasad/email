<?php
session_start();
include('../connection.php');


if(isset($_POST["login_admin"]))
{
    $username=$_POST["username"];
    $password=$_POST["password"];
    $username1=str_replace("@smail.com", "", $username);


if(empty($username))
 { 
  $_SESSION["error"]="Enter your username <br>";
   
    header("Location:../login.php");
 }
 elseif (empty($password)) {
    $_SESSION["error"]="Enter your Password";
    header("Location:../login.php");
 }
 else
 {
  $sql="SELECT * FROM `user` WHERE (`username`='$username1' OR `email`='$username1') AND `password`='$password'";
 	$result=$conn->query($sql);
 	 $total =$result->num_rows;
 	 //$total =COUNT($result);
 	 echo $total ;
 	
 if($total>0)
 { $row = $result->fetch_assoc();
 $_SESSION["username"]=$row["username"];
 $_SESSION["lname"]=$row["lname"];
			 $_SESSION["email"]=$row["email"];
			 $_SESSION["recovery_mail"]=$row["recovery_mail"];
			 $_SESSION["month"]=$row["month"];
       $_SESSION["date"]=$row["date"];
       $_SESSION["year"]=$row["year"];
       $_SESSION["gender"]=$row["gender"];
			 $_SESSION["user_img"]=$row["img"];
       $_SESSION["status"]=$row["status"];
       $_SESSION["star_status"]=$row["star_status"];
 	header("Location:../index.php");
 }
 else{
 	 $_SESSION["error"]=" you are not Register";
 	 header("Location:../login.php");
      }
   
 }
}
elseif (isset($_POST["save_forget"]))
{
  $email=str_replace("@smail.com", "", $_POST["username"]);
  $_SESSION["email"]=$email;
  header("Location: ../recovery_mail.php");
}
else
 {
   $_SESSION["error"]="Wrong Methode is used ";
   
    
 header("Location: ../login.php");

 }
?>
