<?php 
include('../connection.php');
session_start();

if(isset($_POST["save_register"]))
{
	$img=$_FILES['img']['name'];
    $target_dir = "../upload/profile_pic/";
    $target_file = $target_dir . basename($_FILES["img"]["name"]);
    $FileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
   move_uploaded_file($_FILES["img"]["tmp_name"], $target_file);

   $name = $_POST["username"];
   $lname = $_POST["lname"];
   $email = str_replace('@smail.com', "", $_POST["email"]);
   $password = $_POST["password"];
   $cpassword = $_POST["cpassword"];

   $sql_check = "SELECT * FROM `user` WHERE `email`='$email'";
   $result=$conn->query($sql_check);
   $total=$result->num_rows;
    if($total>0)
    {
   	$_SESSION["error"]="This email is already exist";
    header("Location:../signin.php");
    }
   else
   {
   	$sql = "INSERT INTO `user`(`img`, `username`, `lname`, `email`, `password`) VALUES('$img', '$name', '$lname', '$email', '$cpassword')";
   	if($conn->query($sql)==true)
   	{
   		$_SESSION["msg"]="Please enter other details";
      $_SESSION["email"]=$email;
   		header("Location:../signin2.php");
   	}
   	else
   	{
   		$_SESSION["error"]="Something Went Wrong";
   		header("Location:../signin.php");
   	}
   }


}

 ?>