<?php 
include('../connection.php');
session_start();
if(isset($_POST["save_recovery"]))
{	
	$email=$_SESSION["email"];
	$recovery_mail=str_replace("@smail.com", "", $_POST["email"]);
	$smail="smail";
	$smail_data="Smail Verification Code";
	date_default_timezone_set("Asia/Kolkata");
    $date=date('d-M-Y');
	$time=date("h:i:sa");
	$check_mail="SELECT * FROM `user` WHERE `recovery_mail`='$recovery_mail' AND `email`='$email' ";
	$result=$conn->query($check_mail);
	$total=$result->num_rows;
	if($total>0)
	{
		$otp=rand(0000,9999);
		$sql="UPDATE `user` SET `otp`='$otp' WHERE `email`='$email' ";
		if($conn->query($sql)==true)
		{
			$sql_insert="INSERT INTO `user_mail`(`mail_from`, `mail_to`, `forget_mail`, `subject`, `date`, `time`, `status`, `star_status`, `otp`) VALUES ('$smail', '$recovery_mail', '$email', '$smail_data', '$date', '$time', 1, 0, '$otp') ";
			if($conn->query($sql_insert)==true)
			{
				header("Location: ../otp.php");
			}
		}
	}
	else
	{
		$_SESSION["error"]="Enter a valid mail";
		header("Location: ../recovery_mail.php");
	}
}

 ?>