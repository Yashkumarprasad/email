<?php 
include('../connection.php');
if(isset($_GET["id"]))
{
	$id=$_GET["id"];
	$sql="DELETE FROM `user_mail` WHERE `id`='$id' ";
	if($conn->query($sql)==true)
	{
		header("Location:../index.php");
	}
}

 ?>