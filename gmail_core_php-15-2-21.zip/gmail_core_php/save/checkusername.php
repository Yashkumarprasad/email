<?php 
include('../connection.php');
$email=str_replace('@smail.com', "", $_POST["username"]);
$sql_check = "SELECT * FROM `user` WHERE `email`='$email'";
   $result=$conn->query($sql_check);
   $total=$result->num_rows;
    if($total>0)
    {
   	// echo "This email is already exist";
   	echo "0";
    }
    else
    {
    	echo "1";
    }

 ?>