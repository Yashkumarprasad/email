<?php 
include('../connection.php');
session_start();
if(isset($_POST["save_reply"]))
{
	$id=$_POST["id"];
$reply_from = str_replace("@smail.com", "", $_POST["reply_from"]);
	$reply_to = str_replace("@smail.com", "", $_POST["reply_to"]);
	$reply_msg = $_POST["reply_msg"];

	 // $file=$_FILES['file']['name'];
  //   $target_dir = "../upload/reply/";
  //   $target_file = $target_dir . basename($_FILES["file"]["name"]);
  //   $FileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
  //  move_uploaded_file($_FILES["file"]["tmp_name"], $target_file);
 foreach ($_FILES['file']['name'] as $key => $name){
 
		$newFilename = time() . "_" . $name;
		move_uploaded_file($_FILES['file']['tmp_name'][$key], '../upload/reply/' . $newFilename);
$filename[]=$newFilename;

	}
	$file = implode(',', $filename);
   
   $send_date=$_POST["date"];
   $send_time=$_POST["time"];
   $send_msg=$_POST["send_msg"];

    date_default_timezone_set("Asia/Kolkata");
    $date=date('d-M-Y');
	$time=date("h:i:sa");

	$check_mail = "SELECT * FROM `user` WHERE `email`='$reply_to' ";
	$result=$conn->query($check_mail);
	$total=$result->num_rows;
	if($total>0)
	{

	$sql = "INSERT INTO `user_mail` (`reply_from`, `reply_to`, `subject`, `reply_msg`, `img`, `date`, `time`, `send_date`, `send_time`, `send_msg`, `status`, `star_status`)VALUES('$reply_from', '$reply_to', '$reply_msg', '$reply_msg', '$file', '$date', '$time', '$send_date', '$send_time', '$send_msg', 1, 0)";
	if($conn->query($sql)==true)
	{
	// $_SESSION["msg"]="compose successfully send";
 	 header("Location:../read.php?id=$id");
	}
	else
	{
	// $_SESSION["error"]="compose not send";
 	 header("Location:../read.php?id=$id");
	}
   }

}
 ?>
