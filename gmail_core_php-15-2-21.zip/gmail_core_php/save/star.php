<?php 
include('../connection.php');
if(isset($_GET["id"]))
{
	$id=$_GET["id"];
	$status=$_GET["star_status"];

	if($status==0)
	{
		$sql="UPDATE `user_mail` SET `star_status`=1 WHERE `id`='$id' ";
	}
	else
	{
		$sql="UPDATE `user_mail` SET `star_status`=0 WHERE `id`='$id' ";
	}
	if($conn->query($sql)==true)
	{
		header("Location:../index.php");
	}

}

 ?>