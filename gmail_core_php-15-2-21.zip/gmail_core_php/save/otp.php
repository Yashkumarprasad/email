<?php 
include('../connection.php');
session_start();
if(isset($_POST["save_password"]))
{
	$email=$_POST["email"];
	$otp=$_POST["otp"];
	$password=$_POST["password"];
	$cpassword=$_POST["cpassword"];
	$check_otp="SELECT * FROM `user` WHERE `otp`='$otp'  ";
	$result=$conn->query($check_otp);
	$total=$result->num_rows;
	if($total>0)
	{
		if($password==$cpassword)
		{
			$sql="UPDATE `user` SET `password`='$cpassword' WHERE `email`='$email' ";
			if($conn->query($sql)==true)
			{
				$_SESSION["msg"]="Your Password is Change Please Login ! ";
				header("Location:../login.php");
			}
		}
		else
		{
			$_SESSION["error"]="Please Enter a same password";
			header("Location:../otp.php");
		}
	}
	else
	{
		$_SESSION["error"]="Please Enter a valid otp";
		header("Location:../otp.php");
	}
}

 ?>